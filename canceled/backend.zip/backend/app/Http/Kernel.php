protected $middleware = [
    // ...
    \App\Http\Middleware\CorsMiddleware::class,
];
